import numpy as np
import utils

class Surface:

    def intersection(self, ray):
        raise NotImplementedError